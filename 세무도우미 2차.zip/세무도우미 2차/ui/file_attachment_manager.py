
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QPushButton, QDialog, QLabel, QListWidget, QHBoxLayout, QFileDialog
)

class FileAttachmentManager(QWidget):
    def __init__(self, database, clients_data):
        super().__init__()
        self.database = database
        self.clients_data = clients_data

        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout()

        self.open_dialog_button = QPushButton("기본서류 첨부 관리")
        self.open_dialog_button.clicked.connect(self.open_file_attachment_dialog)

        layout.addWidget(self.open_dialog_button)
        self.setLayout(layout)

    def open_file_attachment_dialog(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("기본서류 첨부 관리")
        dialog.resize(600, 400)

        dialog_layout = QVBoxLayout()

        self.file_list = QListWidget()

        button_layout = QHBoxLayout()
        add_button = QPushButton("파일 추가")
        remove_button = QPushButton("파일 삭제")

        add_button.clicked.connect(self.add_file)
        remove_button.clicked.connect(self.remove_file)

        button_layout.addWidget(add_button)
        button_layout.addWidget(remove_button)

        dialog_layout.addWidget(QLabel("첨부된 파일 목록"))
        dialog_layout.addWidget(self.file_list)
        dialog_layout.addLayout(button_layout)

        dialog.setLayout(dialog_layout)
        dialog.exec_()

    def add_file(self):
        options = QFileDialog.Options()
        file_path, _ = QFileDialog.getOpenFileName(self, "파일 선택", "", "모든 파일 (*.*)", options=options)
        if file_path:
            self.file_list.addItem(file_path)

    def remove_file(self):
        selected_items = self.file_list.selectedItems()
        if selected_items:
            for item in selected_items:
                self.file_list.takeItem(self.file_list.row(item))
