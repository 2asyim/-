from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QTabWidget
)
from ui.client_form_manager import ClientFormManager
from ui.file_attachment_manager import FileAttachmentManager
from ui.vat_tab import VatTab
from ui.income_tax_tab import IncomeTaxTab

class ClientManagerWindow(QMainWindow):
    def __init__(self, database, clients_data):
        super().__init__()
        self.database = database
        self.clients_data = clients_data

        self.setWindowTitle("거래처 정보 관리 프로그램")
        self.setGeometry(100, 100, 1200, 800)

        self.setup_ui()

    def setup_ui(self):
        """전체 UI 설정"""
        self.tab_widget = QTabWidget()

        self.setup_client_tab()
        self.setup_vat_tab()
        self.setup_income_tab()

        self.setCentralWidget(self.tab_widget)

    def setup_client_tab(self):
        """거래처 관리 탭 설정"""
        self.client_tab = QWidget()
        self.client_tab_layout = QVBoxLayout(self.client_tab)

        self.client_form_manager = ClientFormManager(self.database, self.clients_data)
        self.client_tab_layout.addWidget(self.client_form_manager)

        self.delivery_manager = FileAttachmentManager(self.database, self.clients_data)
        self.client_tab_layout.addWidget(self.delivery_manager)

        self.tab_widget.addTab(self.client_tab, "거래처 관리")

    def setup_vat_tab(self):
        """부가세 신고 리스트 탭 설정"""
        self.vat_tab = VatTab(self.clients_data)
        self.tab_widget.addTab(self.vat_tab, "부가세 신고 리스트")

    def setup_income_tab(self):
        """종합소득세 신고 리스트 탭 설정"""
        self.income_tab = IncomeTaxTab(self.clients_data)
        self.tab_widget.addTab(self.income_tab, "종합소득세 신고 리스트")
