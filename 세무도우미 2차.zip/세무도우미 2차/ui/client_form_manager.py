from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFormLayout, QLineEdit, QTextEdit,
    QRadioButton, QButtonGroup, QComboBox, QPushButton, QLabel, QTableWidget,
    QTableWidgetItem, QHeaderView
)
from PyQt5.QtCore import Qt
from ui.file_attachment_manager import FileAttachmentManager
from ui.delivery_tab import DeliveryAccountManager

class ClientFormManager(QWidget):
    def __init__(self, database, clients_data):
        super().__init__()
        self.database = database
        self.clients_data = clients_data

        self.setup_ui()

    def setup_ui(self):
        """거래처 관리 메인화면 구성"""

        # 입력필드 생성
        self.name_input = QLineEdit()
        self.biznum_input = QLineEdit()
        self.rep_input = QLineEdit()
        self.rrn_input = QLineEdit()
        self.phone_input = QLineEdit()
        self.fee_input = QLineEdit()
        self.hometax_id_input = QLineEdit()
        self.hometax_pw_input = QLineEdit()

        # 기장/신고대리 버튼
        self.accounting_radio = QRadioButton("기장")
        self.agency_radio = QRadioButton("신고대리")
        self.accounting_type_group = QButtonGroup()
        self.accounting_type_group.addButton(self.accounting_radio)
        self.accounting_type_group.addButton(self.agency_radio)
        self.accounting_radio.setChecked(True)

        accounting_layout = QHBoxLayout()
        accounting_layout.addWidget(self.accounting_radio)
        accounting_layout.addWidget(self.agency_radio)
        accounting_widget = QWidget()
        accounting_widget.setLayout(accounting_layout)

        # 사업자 구분 버튼
        self.ind_radio = QRadioButton("개인")
        self.corp_radio = QRadioButton("법인")
        self.biz_type_group = QButtonGroup()
        self.biz_type_group.addButton(self.ind_radio)
        self.biz_type_group.addButton(self.corp_radio)

        biz_type_layout = QHBoxLayout()
        biz_type_layout.addWidget(self.ind_radio)
        biz_type_layout.addWidget(self.corp_radio)
        biz_type_widget = QWidget()
        biz_type_widget.setLayout(biz_type_layout)

        # 세유형 콤보박스
        self.tax_type_combo = QComboBox()
        self.tax_type_combo.addItems(["일반", "간이", "면세"])

        # 메모 입력란
        self.memo_input = QTextEdit()

        # 좌측 입력폼 (상호명 ~ 연락처)
        left_form = QFormLayout()
        left_form.addRow("상호명", self.name_input)
        left_form.addRow("사업자등록번호", self.biznum_input)
        left_form.addRow("대표자", self.rep_input)
        left_form.addRow("주민등록번호", self.rrn_input)
        left_form.addRow("연락처", self.phone_input)

        # 우측 입력폼 (기장/신고대리 ~ 세유형)
        right_form = QFormLayout()
        right_form.addRow("기장/신고대리", accounting_widget)
        right_form.addRow("기장료", self.fee_input)
        right_form.addRow("홈택스 ID", self.hometax_id_input)
        right_form.addRow("홈택스 PW", self.hometax_pw_input)
        right_form.addRow("사업자 구분", biz_type_widget)
        right_form.addRow("세유형", self.tax_type_combo)

        # 입력란 폭 고정
        for field in [
            self.name_input, self.biznum_input, self.rep_input,
            self.rrn_input, self.phone_input, self.fee_input,
            self.hometax_id_input, self.hometax_pw_input
        ]:
            field.setFixedWidth(200)

        # 상단 입력 레이아웃
        form_layout = QHBoxLayout()
        form_layout.addLayout(left_form)
        form_layout.addLayout(right_form)

        # 검색창
        self.search_input = QLineEdit()
        self.search_button = QPushButton("검색")

        search_layout = QHBoxLayout()
        search_layout.addWidget(QLabel("거래처 검색:"))
        search_layout.addWidget(self.search_input)
        search_layout.addWidget(self.search_button)

        # 거래처 리스트
        self.client_table = QTableWidget()
        self.client_table.setColumnCount(4)
        self.client_table.setHorizontalHeaderLabels(["상호명", "사업자번호", "대표자", "연락처"])
        self.client_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

        # 메모 박스
        memo_layout = QVBoxLayout()
        memo_layout.addWidget(QLabel("메모"))
        memo_layout.addWidget(self.memo_input)

        # 기본서류 첨부 버튼 그룹
        self.file_attachment_manager = FileAttachmentManager(self.database, self.clients_data)

        # 배달계정 관리 버튼 그룹
        self.delivery_manager = DeliveryAccountManager(self.database, self.clients_data)

        # 최종 레이아웃
        main_layout = QVBoxLayout()
        main_layout.addLayout(form_layout)
        main_layout.addLayout(memo_layout)
        main_layout.addLayout(search_layout)
        main_layout.addWidget(self.client_table)
        main_layout.addWidget(self.file_attachment_manager)  # 기본서류 첨부 버튼 추가
        main_layout.addWidget(self.delivery_manager)          # 배달계정 관리 버튼 추가

        self.setLayout(main_layout)
