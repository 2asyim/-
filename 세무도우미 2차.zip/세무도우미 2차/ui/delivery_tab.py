
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QPushButton, QDialog, QLabel, QLineEdit, QFormLayout, QHBoxLayout
)

class DeliveryAccountManager(QWidget):
    def __init__(self, database, clients_data):
        super().__init__()
        self.database = database
        self.clients_data = clients_data

        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout()

        self.open_dialog_button = QPushButton("배달계정 관리")
        self.open_dialog_button.clicked.connect(self.open_delivery_account_dialog)

        layout.addWidget(self.open_dialog_button)
        self.setLayout(layout)

    def open_delivery_account_dialog(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("배달계정 관리")
        dialog.resize(600, 400)

        dialog_layout = QVBoxLayout()

        form_layout = QFormLayout()
        self.account_id_input = QLineEdit()
        self.account_pw_input = QLineEdit()
        self.account_pw_input.setEchoMode(QLineEdit.Password)

        form_layout.addRow("배달계정 ID", self.account_id_input)
        form_layout.addRow("배달계정 PW", self.account_pw_input)

        button_layout = QHBoxLayout()
        save_button = QPushButton("저장")
        close_button = QPushButton("닫기")

        close_button.clicked.connect(dialog.close)

        button_layout.addWidget(save_button)
        button_layout.addWidget(close_button)

        dialog_layout.addLayout(form_layout)
        dialog_layout.addLayout(button_layout)

        dialog.setLayout(dialog_layout)
        dialog.exec_()
