from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem,
    QLineEdit, QPushButton, QHeaderView, QCheckBox, QLabel
)
from PyQt5.QtCore import Qt

class VatTab(QWidget):
    def __init__(self, clients_data):
        super().__init__()
        self.clients_data = clients_data  # 공통 데이터 연동
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout()

        # 검색창과 검색 버튼
        search_layout = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_button = QPushButton("검색")
        search_layout.addWidget(QLabel("상호명 검색"))
        search_layout.addWidget(self.search_input)
        search_layout.addWidget(self.search_button)

        # 테이블 설정
        self.table = QTableWidget()
        self.table.setColumnCount(7)
        self.table.setHorizontalHeaderLabels([
            "상호명", "사업자등록번호", "세유형", "개인/법인", 
            "기본서류 수령", "사업용카드 수령", "부가세 신고완료"
        ])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

        layout.addLayout(search_layout)
        layout.addWidget(self.table)
        self.setLayout(layout)

        # 초기 데이터 표시
        self.populate_table()

        # 검색 버튼 연결
        self.search_button.clicked.connect(self.search_clients)

    def populate_table(self):
        self.table.setRowCount(0)  # 초기화
        sorted_clients = sorted(self.clients_data, key=lambda x: x.get("name", ""))
        for client in sorted_clients:
            row_position = self.table.rowCount()
            self.table.insertRow(row_position)

            # 상호명
            self.table.setItem(row_position, 0, QTableWidgetItem(client.get("name", "")))
            # 사업자등록번호
            self.table.setItem(row_position, 1, QTableWidgetItem(client.get("biznum", "")))
            # 세유형
            self.table.setItem(row_position, 2, QTableWidgetItem(client.get("tax_type", "")))
            # 개인/법인
            self.table.setItem(row_position, 3, QTableWidgetItem(client.get("biz_class", "")))

            # 기본서류 수령 체크박스
            basic_doc_checkbox = QCheckBox()
            basic_doc_checkbox.setChecked(client.get("basic_doc", False))
            self.table.setCellWidget(row_position, 4, basic_doc_checkbox)

            # 사업용카드 수령 체크박스
            card_doc_checkbox = QCheckBox()
            card_doc_checkbox.setChecked(client.get("card_doc", False))
            self.table.setCellWidget(row_position, 5, card_doc_checkbox)

            # 부가세 신고완료 체크박스
            vat_done_checkbox = QCheckBox()
            vat_done_checkbox.setChecked(client.get("vat_done", False))
            self.table.setCellWidget(row_position, 6, vat_done_checkbox)

    def search_clients(self):
        keyword = self.search_input.text().strip()
        if not keyword:
            self.populate_table()
            return

        filtered_clients = [
            client for client in self.clients_data
            if keyword in client.get("name", "")
        ]
        self.table.setRowCount(0)
        for client in filtered_clients:
            row_position = self.table.rowCount()
            self.table.insertRow(row_position)

            self.table.setItem(row_position, 0, QTableWidgetItem(client.get("name", "")))
            self.table.setItem(row_position, 1, QTableWidgetItem(client.get("biznum", "")))
            self.table.setItem(row_position, 2, QTableWidgetItem(client.get("tax_type", "")))
            self.table.setItem(row_position, 3, QTableWidgetItem(client.get("biz_class", "")))

            basic_doc_checkbox = QCheckBox()
            basic_doc_checkbox.setChecked(client.get("basic_doc", False))
            self.table.setCellWidget(row_position, 4, basic_doc_checkbox)

            card_doc_checkbox = QCheckBox()
            card_doc_checkbox.setChecked(client.get("card_doc", False))
            self.table.setCellWidget(row_position, 5, card_doc_checkbox)

            vat_done_checkbox = QCheckBox()
            vat_done_checkbox.setChecked(client.get("vat_done", False))
            self.table.setCellWidget(row_position, 6, vat_done_checkbox)
